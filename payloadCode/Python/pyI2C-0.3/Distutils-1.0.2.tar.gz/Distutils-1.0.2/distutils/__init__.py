"""distutils

The main package for the Python Module Distribution Utilities.  Normally
used from a setup script as

   from distutils.core import setup

   setup (...)
"""

__revision__ = "$Id: __init__.py,v 1.21 2001/04/23 17:13:03 akuchling Exp $"

__version__ = "1.0.2"
