"""sample.py

Sole module in the trivial one-module distribution "sample1" included
as a Distutils test case."""

# created 1999/12/06, Greg Ward

__revision__ = "$Id: sample.py,v 1.1 1999/12/16 01:12:33 gward Exp $"

pass
